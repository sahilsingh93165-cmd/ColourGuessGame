package com.example.colourguess

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    data class C(val name:String,val hex:String)
    private val colours=listOf(
        C("Red","#F44336"),C("Blue","#2196F3"),C("Green","#4CAF50"),C("Yellow","#FFEB3B"),
        C("Orange","#FF9800"),C("Purple","#9C27B0"),C("Pink","#E91E63"),C("Cyan","#00BCD4"),
        C("White","#FFFFFF"),C("Black","#000000"),C("Brown","#795548"),C("Gray","#9E9E9E")
    )
    private var secret=C("",""); private var guess=C("",""); private var phase=1
    lateinit var grid:GridLayout; lateinit var instruction:TextView; lateinit var message:TextView; lateinit var action:Button

    override fun onCreate(b:Bundle?){super.onCreate(b); setContentView(R.layout.activity_main)
        grid=findViewById(R.id.grid); instruction=findViewById(R.id.instruction); message=findViewById(R.id.message); action=findViewById(R.id.action)
        action.setOnClickListener { if(phase==3) reveal() else if(phase==4) reset() }
        showPalette()
    }
    fun showPalette(){
        grid.removeAllViews()
        colours.forEach{ c->
            val v=TextView(this); v.text=""; v.setBackgroundColor(Color.parseColor(c.hex))
            val p=GridLayout.LayoutParams(); p.width=0; p.height=90; p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); p.setMargins(6,6,6,6)
            v.layoutParams=p; v.setOnClickListener{ if(phase==1) lock(c) else if(phase==2) startGuess() else if(phase==3){guess=c; message.text="Your guess: ${c.name} 👀"} }
            grid.addView(v)
        }
        action.visibility=if(phase==3||phase==4) View.VISIBLE else View.GONE
    }
    fun lock(c:C){secret=c;phase=2;grid.removeAllViews();instruction.text="🔐 Colour locked!";message.text="Pass the phone to Player 2.";action.visibility=View.VISIBLE;action.text="I'm Player 2";action.setOnClickListener{startGuess()}}
    fun startGuess(){phase=3;instruction.text="Player 2: Which colour was chosen?";message.text="Choose your guess.";action.visibility=View.VISIBLE;action.text="🔓 Reveal";action.setOnClickListener{reveal()};showPalette()}
    fun reveal(){phase=4;grid.removeAllViews();instruction.text=if(guess.name==secret.name)"🎉 CORRECT!" else "❌ Not quite!";message.text="Player 1 chose: ${secret.name}";action.text="🔄 Play Again"}
    fun reset(){secret=C("","");guess=C("","");phase=1;instruction.text="Player 1: choose a colour";message.text="";action.visibility=View.GONE;showPalette()}
}
